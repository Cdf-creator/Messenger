import ScadeKit

class LoginPageAdapter: SCDLatticePageAdapter {

  // page adapter initialization
  override func load(_ path: String) {
    super.load(path)

    self.createAccountButton.onClick { _ in
      self.navigation!.go(page: "signUp.page", transition: SCDLatticeTransition.fromLeft)

    }

    self.signInButton.onClick { _ in self.loginButtonTapped()

    }

    self.passwordTextbox.keyboardType = .number

  }

  private func loginButtonTapped() {

    let email = emailTextbox.text
    let password = passwordTextbox.text
    guard !email.isEmpty, !password.isEmpty, password.count >= 8
    else {
      self.alertUserLoginErrorLabel.text =
        "Please enter all information to sign in."
      return
    }

    self.alertUserLoginErrorLabel.text = ""

    self.signInButton.onClick { _ in
      self.navigation!.go(page: "main.page", transition: SCDLatticeTransition.fromRight)
    }

    // Firebase Sign In

  }

}
