import ScadeKit
  
class MainPageAdapter: SCDLatticePageAdapter {
  
  // page adapter initialization
  override func load(_ path: String) {
    super.load(path)
    
    self.logOutButton.onClick { _ in self.logOutButtonTapped()

    }
    
  }
  
  private func logOutButtonTapped () {
  
  self.logOutButton.onClick { _ in
      self.navigation!.go(page: "login.page", transition: SCDLatticeTransition.fromRight)
    }
  	
  }
  
}
